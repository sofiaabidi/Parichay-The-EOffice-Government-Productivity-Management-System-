import { useState } from 'react';
import { AlertCircle, Check, X, Clock, FileText, MessageSquare } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';

interface PendingApproval {
  id: string;
  task: string;
  daysLeft: number;
  assignedTo: string;
  deadline: string;
  documentName: string;
}

const dummyApprovals: PendingApproval[] = [
  {
    id: '1',
    task: 'Compile attendance analytics',
    daysLeft: 2,
    assignedTo: 'Riya Das',
    deadline: 'Nov 29, 2025',
    documentName: 'attendance_pack.pdf',
  },
];

export function PendingApprovalsSection() {
  const [approvals, setApprovals] = useState<PendingApproval[]>(dummyApprovals);
  const [remarkDialogOpen, setRemarkDialogOpen] = useState(false);
  const [selectedApprovalId, setSelectedApprovalId] = useState<string | null>(null);
  const [remark, setRemark] = useState('');

  const handleApprove = (id: string) => {
    setApprovals(approvals.filter((approval) => approval.id !== id));
    toast.success('Approval request approved');
  };

  const handleReject = (id: string) => {
    setApprovals(approvals.filter((approval) => approval.id !== id));
    toast.success('Approval request rejected');
  };

  const handleAddRemark = (id: string) => {
    setSelectedApprovalId(id);
    setRemark('');
    setRemarkDialogOpen(true);
  };

  const handleSubmitRemark = () => {
    if (remark.trim()) {
      toast.success('Remark added successfully');
      setRemarkDialogOpen(false);
      setRemark('');
      setSelectedApprovalId(null);
    } else {
      toast.error('Please enter a remark');
    }
  };

  const handleDialogClose = (open: boolean) => {
    if (!open) {
      setRemarkDialogOpen(false);
      setRemark('');
      setSelectedApprovalId(null);
    }
  };

  const pendingCount = approvals.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-orange-500" />
          <h2 className="text-gray-900">Pending Approvals for Surveys</h2>
        </div>
        {pendingCount > 0 && (
          <div className="bg-gray-800 px-4 py-2 rounded-xl">
            <p className="text-sm text-white">{pendingCount} pending</p>
          </div>
        )}
      </div>

      {/* Approval Cards */}
      {approvals.length === 0 ? (
        <Card className="p-6 shadow-lg border-0 rounded-2xl">
          <div className="text-center py-12 text-gray-400">
            <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No pending approvals</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {approvals.map((approval) => (
            <Card
              key={approval.id}
              className="p-6 shadow-lg border-0 rounded-2xl bg-yellow-50"
            >
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                {/* Left side - Approval details */}
                <div className="flex-1 space-y-3">
                  <div className="flex items-start gap-3">
                    <h3 className="text-gray-900 font-medium text-lg">
                      {approval.task}
                    </h3>
                    <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 whitespace-nowrap">
                      <Clock className="w-3 h-3" />
                      {approval.daysLeft} days left
                    </span>
                  </div>

                  <div className="space-y-1 text-sm text-gray-600">
                    <p>Assigned to: {approval.assignedTo}</p>
                    <p>Deadline: {approval.deadline}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="link"
                      className="text-blue-600 p-0 h-auto font-normal"
                      onClick={() => toast.info(`Opening ${approval.documentName}`)}
                    >
                      <FileText className="w-4 h-4 mr-1" />
                      {approval.documentName}
                    </Button>
                  </div>
                </div>

                {/* Right side - Action buttons */}
                <div className="flex flex-col sm:flex-row gap-2 lg:flex-col">
                  <Button
                    onClick={() => handleApprove(approval.id)}
                    className="bg-green-600 hover:bg-green-700 text-white rounded-xl flex items-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                  <Button
                    onClick={() => handleReject(approval.id)}
                    variant="destructive"
                    className="rounded-xl flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Reject
                  </Button>
                  <Dialog 
                    open={remarkDialogOpen && selectedApprovalId === approval.id} 
                    onOpenChange={handleDialogClose}
                  >
                    <Button
                      onClick={() => handleAddRemark(approval.id)}
                      variant="outline"
                      className="rounded-xl flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      Add Remark
                    </Button>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Add Remark</DialogTitle>
                        <DialogDescription>
                          Add a remark for: {approval.task}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <Textarea
                          placeholder="Enter your remark here..."
                          value={remark}
                          onChange={(e) => setRemark(e.target.value)}
                          className="min-h-32"
                        />
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setRemarkDialogOpen(false);
                            setRemark('');
                            setSelectedApprovalId(null);
                          }}
                        >
                          Cancel
                        </Button>
                        <Button onClick={handleSubmitRemark}>Submit</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

