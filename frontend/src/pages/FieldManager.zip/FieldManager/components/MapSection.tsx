import { useState, useCallback, useRef } from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { MapPin, Save, Search, RefreshCw, Eye, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { toast } from 'sonner';

interface Location {
  id: string;
  lat: number;
  lng: number;
  timestamp: string;
}

interface PinPosition {
  lat: number;
  lng: number;
}

const mapContainerStyle = {
  width: '100%',
  height: '500px',
  borderRadius: '16px',
};

const defaultCenter = {
  lat: 26.166094,
  lng: 90.815865
};

const GOOGLE_MAPS_API_KEY = 'AIzaSyDDhWGybaofdMrXHWR3TevoslQn6P-lRAQ';

const isApiKeyConfigured = GOOGLE_MAPS_API_KEY.length > 0 && GOOGLE_MAPS_API_KEY !== 'YOUR_GOOGLE_MAPS_API_KEY';

export function MapSection() {
  const [pinPosition, setPinPosition] = useState<PinPosition | null>(null);
  const [locationId, setLocationId] = useState('');
  const [savedLocations, setSavedLocations] = useState<Location[]>([]);
  const [showInfoWindow, setShowInfoWindow] = useState(false);
  const [searchId, setSearchId] = useState('');
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [mapZoom, setMapZoom] = useState(13);
  const mapRef = useRef<google.maps.Map | null>(null);
  const [animatingPin, setAnimatingPin] = useState(false);
  const [mapError, setMapError] = useState(false);

  const useDemoMode = !isApiKeyConfigured || mapError;

  const handlePlaceholderMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const lat = 40.7128 + (y / rect.height - 0.5) * 0.1;
    const lng = -74.0060 + (x / rect.width - 0.5) * 0.1;

    setPinPosition({ lat, lng });
    setShowInfoWindow(true);
    setAnimatingPin(true);
    setTimeout(() => setAnimatingPin(false), 600);
  };

  const onLoadError = useCallback((error: Error) => {
    console.error('Google Maps API Error:', error);
    setMapError(true);
    toast.error('Map service unavailable. Using demo mode.');
  }, []);

  const onLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
  }, []);

  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng) {
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();

      setPinPosition({ lat, lng });
      setShowInfoWindow(true);
      setAnimatingPin(true);
      setTimeout(() => setAnimatingPin(false), 600);
    }
  }, []);

  const handleSaveLocation = () => {
    if (!pinPosition) {
      toast.error('Please select a location on the map');
      return;
    }

    if (!locationId.trim()) {
      toast.error('Please enter a Location ID');
      return;
    }

    if (savedLocations.some(loc => loc.id === locationId)) {
      toast.error('Location ID already exists');
      return;
    }

    const newLocation: Location = {
      id: locationId,
      lat: pinPosition.lat,
      lng: pinPosition.lng,
      timestamp: new Date().toLocaleString(),
    };

    setSavedLocations([...savedLocations, newLocation]);
    toast.success(`Location "${locationId}" saved successfully`);
    setLocationId('');
  };

  const handleFetchById = () => {
    if (!searchId.trim()) {
      toast.error('Please enter a Location ID to fetch');
      return;
    }

    const location = savedLocations.find(loc => loc.id === searchId);

    if (!location) {
      toast.error('Invalid ID - Location not found');
      return;
    }

    setPinPosition({ lat: location.lat, lng: location.lng });
    setMapCenter({ lat: location.lat, lng: location.lng });
    setMapZoom(16);
    setShowInfoWindow(true);
    setAnimatingPin(true);
    setTimeout(() => setAnimatingPin(false), 600);

    toast.success(`Location "${location.id}" loaded`);
    setSearchId('');
  };

  const handleClearPin = () => {
    setPinPosition(null);
    setShowInfoWindow(false);
    setLocationId('');
    toast.info('Pin cleared');
  };

  const handleViewOnMap = (location: Location) => {
    setPinPosition({ lat: location.lat, lng: location.lng });
    setMapCenter({ lat: location.lat, lng: location.lng });
    setMapZoom(16);
    setShowInfoWindow(true);
    setAnimatingPin(true);
    setTimeout(() => setAnimatingPin(false), 600);
    toast.info(`Viewing location "${location.id}"`);
  };

  const handleDeleteLocation = (id: string) => {
    setSavedLocations(savedLocations.filter(loc => loc.id !== id));
    toast.success(`Location "${id}" deleted`);
  };

  const isSaveEnabled = pinPosition !== null && locationId.trim() !== '';

  return (
    <div className="space-y-6">
      
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-gray-900">Location Assignment</h2>
          <p className="text-sm text-gray-500 mt-1">Pin and manage field work locations</p>
        </div>
        <div className="bg-blue-50 px-4 py-2 rounded-xl border border-blue-100">
          <p className="text-sm text-blue-600">{savedLocations.length} locations saved</p>
        </div>
      </div>

      {/* ======================== MAP LEFT + SAVE/FETCH RIGHT ======================== */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* LEFT: MAP */}
        <div className="lg:col-span-2">
          <Card className="p-6 shadow-lg border-0 rounded-2xl">
            <div className="mb-4">
              <h3 className="text-gray-900">Interactive Map</h3>
              <p className="text-sm text-gray-500 mt-1">
                <MapPin className="w-4 h-4 inline mr-1" /> Click on the map to choose a location
              </p>
            </div>

            <div className="relative rounded-2xl overflow-hidden shadow-md">
              {!isApiKeyConfigured || mapError ? (
                /* DEMO MODE MAP */
                <div
                  className="w-full h-[500px] bg-gradient-to-br from-blue-100 to-green-100 relative cursor-crosshair"
                  onClick={handlePlaceholderMapClick}
                >
                  {/* demo pin */}
                  {pinPosition && (
                    <div
                      className={`absolute transform -translate-x-1/2 -translate-y-full ${
                        animatingPin ? 'animate-bounce' : ''
                      }`}
                      style={{ left: '50%', top: '50%' }}
                    >
                      <MapPin className="w-10 h-10 text-red-600 fill-red-600" />
                    </div>
                  )}
                </div>
              ) : (
                /* REAL GOOGLE MAP */
                <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY} onError={onLoadError}>
                  <GoogleMap
                    mapContainerStyle={mapContainerStyle}
                    center={mapCenter}
                    zoom={mapZoom}
                    onClick={handleMapClick}
                    onLoad={onLoad}
                    options={{
                      streetViewControl: false,
                      mapTypeControl: true,
                      fullscreenControl: false,
                    }}
                  >
                    {pinPosition && (
                      <>
                        <Marker
                          position={pinPosition}
                          animation={animatingPin ? google.maps.Animation.BOUNCE : undefined}
                        />
                        {showInfoWindow && (
                          <InfoWindow
                            position={pinPosition}
                            onCloseClick={() => setShowInfoWindow(false)}
                          >
                            <div>
                              <p>Lat: {pinPosition.lat.toFixed(6)}</p>
                              <p>Lng: {pinPosition.lng.toFixed(6)}</p>
                            </div>
                          </InfoWindow>
                        )}
                      </>
                    )}
                  </GoogleMap>
                </LoadScript>
              )}
            </div>
          </Card>
        </div>

        {/* RIGHT: SAVE + FETCH */}
        <div className="flex flex-col gap-6">

          {/* SAVE */}
          <Card className="p-6 shadow-lg border-0 rounded-2xl">
            <div className="flex items-center gap-2 mb-4">
              <Save className="w-5 h-5 text-[#2563EB]" />
              <h3 className="text-gray-900">Save Location</h3>
            </div>

            <div className="space-y-4">
              <Input
                placeholder="Enter unique location number"
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="rounded-xl"
              />

              <Button
                onClick={handleSaveLocation}
                disabled={!isSaveEnabled}
                className="w-full rounded-xl color-blue"
              >
                <Save className="w-4 h-4 mr-2" /> Save Location
              </Button>

              <Button onClick={handleClearPin} variant="outline" className="w-full rounded-xl">
                <RefreshCw className="w-4 h-4 mr-2" /> Clear Pin
              </Button>
            </div>
          </Card>

          {/* FETCH */}
          <Card className="p-6 shadow-lg border-0 rounded-2xl">
            <div className="flex items-center gap-2 mb-4">
              <Search className="w-5 h-5 text-[#2563EB]" />
              <h3 className="text-gray-900">Fetch Location</h3>
            </div>

            <div className="space-y-4">
              <Input
                placeholder="Enter location ID"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                className="rounded-xl"
                onKeyPress={(e) => e.key === 'Enter' && handleFetchById()}
              />

              <Button onClick={handleFetchById} variant="secondary" className="w-full rounded-xl">
                <Search className="w-4 h-4 mr-2" /> Fetch by ID
              </Button>
            </div>
          </Card>

          {/* CURRENT PIN */}
          {pinPosition && (
            <Card className="p-6 shadow-lg border-0 rounded-2xl bg-blue-50 border-blue-100">
              <p className="text-sm text-blue-900 mb-1">Current Pin</p>
              <p className="text-xs text-blue-700">Lat: {pinPosition.lat.toFixed(6)}</p>
              <p className="text-xs text-blue-700">Lng: {pinPosition.lng.toFixed(6)}</p>
            </Card>
          )}
        </div>

      </div>
      {/* ======================== END OF MAP + CONTROLS ROW ======================== */}

      {/* ======================== TABLE BELOW ======================== */}
      <Card className="p-6 shadow-lg border-0 rounded-2xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-900">Saved Locations</h3>
          <span className="text-sm text-gray-500">{savedLocations.length} total</span>
        </div>

        {savedLocations.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No locations saved yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 text-sm">ID</th>
                  <th className="py-3 text-sm">Lat</th>
                  <th className="py-3 text-sm">Lng</th>
                  <th className="py-3 text-sm">Saved On</th>
                  <th className="py-3 text-sm text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {savedLocations.map((loc) => (
                  <tr key={loc.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 text-center">{loc.id}</td>
                    <td className="py-3 text-center">{loc.lat.toFixed(6)}</td>
                    <td className="py-3 text-center">{loc.lng.toFixed(6)}</td>
                    <td className="py-3 text-center">{loc.timestamp}</td>
                    <td className="py-3 text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="ghost" onClick={() => handleViewOnMap(loc)}>
                          <Eye className="w-4 h-4 mr-1" /> View
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-600"
                          onClick={() => handleDeleteLocation(loc.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

    </div>
  );
}
