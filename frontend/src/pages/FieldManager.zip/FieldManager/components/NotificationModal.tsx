import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface NotificationModalProps {
  open: boolean;
  onClose: () => void;
}

// Dummy notification data
const dummyNotifications = [
  {
    id: 1,
    title: 'New Task Assigned',
    message: 'You have been assigned a new project task: Site Survey - Location A',
    time: '2 hours ago',
    type: 'task',
  },
  {
    id: 2,
    title: 'Approval Required',
    message: 'Employee attendance report for Week 3 needs your approval',
    time: '5 hours ago',
    type: 'approval',
  },
  {
    id: 3,
    title: 'Team Update',
    message: '3 employees have checked in today',
    time: '1 day ago',
    type: 'update',
  },
  {
    id: 4,
    title: 'Reminder',
    message: 'Monthly performance review meeting scheduled for tomorrow at 10 AM',
    time: '2 days ago',
    type: 'reminder',
  },
  {
    id: 5,
    title: 'System Notification',
    message: 'Your weekly report has been successfully submitted',
    time: '3 days ago',
    type: 'system',
  },
];

export function NotificationModal({ open, onClose }: NotificationModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-[#1F2937]">Notifications</DialogTitle>
        </DialogHeader>
        <div className="max-h-[500px] overflow-y-auto">
          {dummyNotifications.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No notifications
            </div>
          ) : (
            <div className="space-y-3">
              {dummyNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-[#1F2937] mb-1">
                        {notification.title}
                      </h4>
                      <p className="text-sm text-gray-600 mb-2">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-400">{notification.time}</p>
                    </div>
                    <div className="w-2 h-2 rounded-full bg-blue-600 mt-1"></div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

