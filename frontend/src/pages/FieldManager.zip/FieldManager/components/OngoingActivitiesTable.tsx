import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Plus, Check, X, FileText, Image as ImageIcon, Eye, Star } from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { AddTaskDialog } from './AddTaskDialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { toast } from 'sonner';

interface SubmissionFile {
  id: string;
  name: string;
  type: 'pdf' | 'image';
  url?: string;
}

interface Task {
  id: string;
  name: string;
  assignedTo: string;
  deadline: string;
  status: 'assigned' | 'awaiting-approval' | 'completed';
  submissions?: SubmissionFile[];
  cost?: string;
}

interface Milestone {
  id: number;
  name: string;
  status: 'completed' | 'in-progress' | 'pending';
  progress: number;
  deadline?: string;
  budget?: string;
  expectedOutcome?: string;
  tasks?: Task[];
  isFinalDPR?: boolean;
}

interface Project {
  id: number;
  name: string;
  description: string | null;
  status: string;
  due_date: string | null;
  progress_percent?: number;
  total_tasks?: number;
  completed_tasks?: number;
  milestones?: Milestone[];
}

interface TeamMember {
  id: number;
  name: string;
  email: string;
  role?: string;
  designation?: string;
}

export function OngoingActivitiesTable() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [expandedProjects, setExpandedProjects] = useState<number[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [addTaskDialogOpen, setAddTaskDialogOpen] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [actionDialogOpen, setActionDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<{
    projectId: number;
    milestoneId: number;
    taskId: string;
    taskName: string
  } | null>(null);
  const [feedback, setFeedback] = useState('');
  const [reviewDPRDialogOpen, setReviewDPRDialogOpen] = useState(false);
  const [selectedProjectForReview, setSelectedProjectForReview] = useState<number | null>(null);
  const [dprRatings, setDprRatings] = useState({
    authenticity: 0,
    useOfCorrectData: 0,
    technicalCorrectness: 0,
    completeness: 0,
    toolsAndResourcesUsed: 0,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    // Using dummy data instead of API calls
    setLoading(true);

    // Dummy team members
    const dummyTeamMembers: TeamMember[] = [
      { id: 1, name: 'Rajesh Kumar', email: 'rajesh@example.com', designation: 'Field Engineer' },
      { id: 2, name: 'Priya Sharma', email: 'priya@example.com', designation: 'Surveyor' },
      { id: 3, name: 'Amit Patel', email: 'amit@example.com', designation: 'Site Supervisor' },
      { id: 4, name: 'Sneha Reddy', email: 'sneha@example.com', designation: 'Project Coordinator' },
    ];

    // Dummy projects matching the image
    const dummyProjects: Project[] = [
      {
        id: 1,
        name: 'Infrastructure Development – Zone A',
        description: 'Development of road infrastructure and drainage systems in residential zone A',
        status: 'active',
        due_date: '2024-12-15',
        progress_percent: 65,
        total_tasks: 45,
        completed_tasks: 29,
        milestones: [
          {
            id: 1,
            name: 'Site Survey & Assessment',
            status: 'completed',
            progress: 100,
            deadline: '2024-10-20',
            budget: '₹5,00,000',
            expectedOutcome: 'Detailed site survey report with measurements and photographs',
            tasks: [
              {
                id: 'TASK-001',
                name: 'Conduct site measurements',
                assignedTo: 'Rajesh Kumar',
                deadline: '2024-10-15',
                status: 'completed',
                cost: '₹2,50,000',
                submissions: [
                  { id: 'sub1', name: 'measurements_report.pdf', type: 'pdf' },
                  { id: 'sub2', name: 'site_photo_1.jpg', type: 'image' },
                ],
              },
              {
                id: 'TASK-002',
                name: 'Take site photographs',
                assignedTo: 'Priya Sharma',
                deadline: '2024-10-18',
                status: 'completed',
                cost: '₹2,50,000',
                submissions: [
                  { id: 'sub3', name: 'photo_gallery.zip', type: 'image' },
                ],
              },
            ],
          },
          {
            id: 2,
            name: 'DPR Draft Preparation',
            status: 'in-progress',
            progress: 65,
            deadline: '2024-11-30',
            budget: '₹15,00,000',
            expectedOutcome: 'Complete DPR with cost estimates and technical specifications',
            tasks: [
              {
                id: 'TASK-003',
                name: 'Prepare cost estimates',
                assignedTo: 'Amit Patel',
                deadline: '2024-11-25',
                status: 'awaiting-approval',
                cost: '₹6,00,000',
                submissions: [
                  { id: 'sub4', name: 'cost_estimate.xlsx', type: 'pdf' },
                  { id: 'sub5', name: 'budget_breakdown.pdf', type: 'pdf' },
                ],
              },
              {
                id: 'TASK-004',
                name: 'Draft technical specifications',
                assignedTo: 'Sneha Reddy',
                deadline: '2024-11-28',
                status: 'assigned',
                cost: '₹5,00,000',
                submissions: [],
              },
              {
                id: 'TASK-005',
                name: 'Review DPR draft',
                assignedTo: 'Rajesh Kumar',
                deadline: '2024-11-30',
                status: 'assigned',
                cost: '₹4,00,000',
                submissions: [],
              },
            ],
          },
          {
            id: 3,
            name: 'Final DPR Preparation',
            status: 'pending',
            progress: 0,
            deadline: '2024-12-15',
            budget: '₹25,00,000',
            expectedOutcome: 'Final approved DPR with all necessary approvals',
            tasks: [],
            isFinalDPR: true,
          },
        ],
      },
      {
        id: 2,
        name: 'Rural Road Construction - Block 12',
        description: 'Construction of 5km rural road connecting villages in Block 12',
        status: 'active',
        due_date: '2024-12-20',
        progress_percent: 40,
        total_tasks: 78,
        completed_tasks: 31,
        milestones: [
          {
            id: 1,
            name: 'Preliminary Survey',
            status: 'completed',
            progress: 100,
            deadline: '2024-10-15',
            budget: '₹3,00,000',
            expectedOutcome: 'Route survey and feasibility report',
            tasks: [
              {
                id: 'TASK-006',
                name: 'Route mapping',
                assignedTo: 'Priya Sharma',
                deadline: '2024-10-10',
                status: 'completed',
                cost: '₹3,00,000',
                submissions: [
                  { id: 'sub6', name: 'route_map.pdf', type: 'pdf' },
                  { id: 'sub7', name: 'route_photo.jpg', type: 'image' },
                ],
              },
            ],
          },
          {
            id: 2,
            name: 'Soil Testing & Analysis',
            status: 'in-progress',
            progress: 40,
            deadline: '2024-11-25',
            budget: '₹8,00,000',
            expectedOutcome: 'Soil test reports and foundation recommendations',
            tasks: [
              {
                id: 'TASK-007',
                name: 'Collect soil samples',
                assignedTo: 'Amit Patel',
                deadline: '2024-11-20',
                status: 'awaiting-approval',
                cost: '₹4,50,000',
                submissions: [
                  { id: 'sub8', name: 'soil_test_report.pdf', type: 'pdf' },
                  { id: 'sub9', name: 'sample_photo_1.jpg', type: 'image' },
                  { id: 'sub10', name: 'sample_photo_2.jpg', type: 'image' },
                ],
              },
              {
                id: 'TASK-008',
                name: 'Analyze soil composition',
                assignedTo: 'Rajesh Kumar',
                deadline: '2024-11-23',
                status: 'assigned',
                cost: '₹3,50,000',
                submissions: [],
              },
            ],
          },
          {
            id: 3,
            name: 'Final DPR Preparation',
            status: 'pending',
            progress: 0,
            deadline: '2024-12-20',
            budget: '₹20,00,000',
            expectedOutcome: 'Final approved DPR with all necessary approvals',
            tasks: [],
            isFinalDPR: true,
          },
        ],
      },
    ];

    setProjects(dummyProjects);
    setTeamMembers(dummyTeamMembers);
    setLoading(false);
  };

  const toggleProject = (projectId: number) => {
    if (expandedProjects.includes(projectId)) {
      setExpandedProjects(expandedProjects.filter(id => id !== projectId));
    } else {
      setExpandedProjects([...expandedProjects, projectId]);
    }
  };

  const handleAddTaskClick = (projectId: number) => {
    setSelectedProjectId(projectId);
    setAddTaskDialogOpen(true);
  };

  const handleTaskAdded = () => {
    // Just close the dialog, no need to reload since we're using dummy data
    toast.success('Task added successfully');
    setAddTaskDialogOpen(false);
    setSelectedProjectId(null);
  };

  const getDaysUntilDeadline = (deadline: string | null) => {
    if (!deadline) return null;
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'pending':
        return 'bg-gray-100 text-gray-700 border-gray-300';
      case 'active':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      default:
        return 'bg-blue-100 text-blue-700 border-blue-300';
    }
  };

  const getMilestoneStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'pending':
        return 'bg-gray-100 text-gray-700 border-gray-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getTaskStatusColor = (status: string) => {
    switch (status) {
      case 'assigned':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'awaiting-approval':
        return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const handleTakeAction = (projectId: number, milestoneId: number, taskId: string, taskName: string) => {
    setSelectedTask({ projectId, milestoneId, taskId, taskName });
    setFeedback('');
    setActionDialogOpen(true);
  };

  const handleAcceptTask = () => {
    if (!selectedTask) return;

    if (!feedback.trim()) {
      toast.error('Please enter feedback before accepting');
      return;
    }

    setProjects(prevProjects => {
      return prevProjects.map(project => {
        if (project.id === selectedTask.projectId) {
          return {
            ...project,
            milestones: project.milestones?.map(milestone => {
              if (milestone.id === selectedTask.milestoneId) {
                return {
                  ...milestone,
                  tasks: milestone.tasks?.map(task => {
                    if (task.id === selectedTask.taskId) {
                      return { ...task, status: 'completed' as const };
                    }
                    return task;
                  }),
                };
              }
              return milestone;
            }),
          };
        }
        return project;
      });
    });
    toast.success('Task accepted successfully');
    setActionDialogOpen(false);
    setFeedback('');
    setSelectedTask(null);
  };

  const handleRejectTask = () => {
    if (!selectedTask) return;

    if (!feedback.trim()) {
      toast.error('Please enter feedback before rejecting');
      return;
    }

    setProjects(prevProjects => {
      return prevProjects.map(project => {
        if (project.id === selectedTask.projectId) {
          return {
            ...project,
            milestones: project.milestones?.map(milestone => {
              if (milestone.id === selectedTask.milestoneId) {
                return {
                  ...milestone,
                  tasks: milestone.tasks?.map(task => {
                    if (task.id === selectedTask.taskId) {
                      return { ...task, status: 'assigned' as const };
                    }
                    return task;
                  }),
                };
              }
              return milestone;
            }),
          };
        }
        return project;
      });
    });
    toast.success('Task rejected');
    setActionDialogOpen(false);
    setFeedback('');
    setSelectedTask(null);
  };

  const handleReviewDPR = (projectId: number) => {
    setSelectedProjectForReview(projectId);
    setDprRatings({
      authenticity: 0,
      useOfCorrectData: 0,
      technicalCorrectness: 0,
      completeness: 0,
      toolsAndResourcesUsed: 0,
    });
    setReviewDPRDialogOpen(true);
  };

  const handleSubmitDPRReview = () => {
    // Check if all ratings are provided
    const ratings = Object.values(dprRatings) as number[];
    const allRated = ratings.every((rating) => rating > 0);
    if (!allRated) {
      toast.error('Please rate all parameters');
      return;
    }

    toast.success('DPR Review submitted successfully');
    setReviewDPRDialogOpen(false);
    setSelectedProjectForReview(null);
    setDprRatings({
      authenticity: 0,
      useOfCorrectData: 0,
      technicalCorrectness: 0,
      completeness: 0,
      toolsAndResourcesUsed: 0,
    });
  };

  const StarRating = ({
    rating,
    onRatingChange,
    label
  }: {
    rating: number;
    onRatingChange: (rating: number) => void;
    label: string;
  }) => {
    return (
      <div className="space-y-2">
        <Label className="text-sm font-medium text-[#1F2937]">{label}</Label>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => onRatingChange(star)}
              className="focus:outline-none"
            >
              <Star
                className={`w-6 h-6 transition-colors ${star <= rating
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300 hover:text-yellow-300'
                  }`}
              />
            </button>
          ))}
          {rating > 0 && (
            <span className="ml-2 text-sm text-gray-600">({rating}/5)</span>
          )}
        </div>
      </div>
    );
  };

  const calculateProgress = (project: Project) => {
    if (project.progress_percent !== undefined && project.progress_percent !== null) {
      return Number(project.progress_percent);
    }
    if (project.status === 'completed') return 100;
    if (project.status === 'on-hold') return 50;
    return 0;
  };

  const activeProjects = projects.filter(p => p.status === 'active' || !p.status || p.status === 'in-progress');

  if (loading) {
    return (
      <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6">
        <div className="text-center py-8">Loading projects...</div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-[#1F2937] text-xl font-semibold">My Projects</h2>
          <Badge className="bg-blue-50 text-blue-700 border-blue-300 px-3 py-1 rounded-lg">
            {activeProjects.length} Active Projects
          </Badge>
        </div>
      </div>

      <div className="p-6 space-y-4">
        {activeProjects.length === 0 ? (
          <div className="text-center py-8 text-gray-500">No active projects found</div>
        ) : (
          activeProjects.map((project) => {
            const isExpanded = expandedProjects.includes(project.id);
            const progress = calculateProgress(project);
            const daysLeft = getDaysUntilDeadline(project.due_date);
            const milestones = project.milestones || [];

            return (
              <div key={project.id} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                {/* Project Header */}
                <div className="p-6 border-b border-gray-200">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-[#1F2937] text-lg font-semibold">{project.name}</h3>
                        <Badge className={`${getStatusColor('active')} px-3 py-1 rounded-full`}>
                          active
                        </Badge>
                      </div>
                      <p className="text-[#6B6B6B] mb-3">{project.description || 'No description available'}</p>
                      <div className="flex items-center gap-6 text-sm">
                        <div>
                          <span className="text-[#6B6B6B]">Budget: </span>
                          <span className="text-[#1F2937]">
                            {project.id === 1 ? '₹45,00,000' : project.id === 2 ? '₹78,50,000' : '₹N/A'}
                          </span>
                        </div>
                        <div>
                          <span className="text-[#6B6B6B]">DPR Deadline: </span>
                          <span
                            className={daysLeft !== null && daysLeft < 0 ? 'text-red-600' : daysLeft !== null && daysLeft < 7 ? 'text-orange-600' : 'text-[#1F2937]'}
                          >
                            {formatDate(project.due_date)} {daysLeft !== null && `(${daysLeft < 0 ? '-' : ''}${Math.abs(daysLeft)} days left)`}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAddTaskClick(project.id)}
                        className="bg-blue-600 hover:bg-blue-700 text-white border-0"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Task
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleProject(project.id)}
                      >
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </Button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-[#6B6B6B]">Overall Progress</span>
                      <span className="text-sm text-[#1F2937]">{progress}%</span>
                    </div>
                    <div className="bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Expanded Content - Milestones */}
                {isExpanded && milestones.length > 0 && (
                  <div className="p-6 space-y-4 bg-gray-50">
                    <h4 className="text-[#1F2937] font-semibold">Milestones</h4>
                    {milestones.map((milestone) => (
                      <div
                        key={milestone.id}
                        className="bg-white border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="text-[#1F2937] font-medium">{milestone.name}</span>
                              <Badge className={`${getMilestoneStatusColor(milestone.status)} px-2 py-0.5 rounded-full text-xs`}>
                                {milestone.status}
                              </Badge>
                            </div>
                            {milestone.deadline && (
                              <div className="text-sm text-[#6B6B6B] mb-2">
                                Deadline: {formatDate(milestone.deadline)}
                              </div>
                            )}
                            {milestone.budget && (
                              <div className="text-sm text-[#6B6B6B] mb-2">
                                Budget: {milestone.budget}
                              </div>
                            )}
                            {milestone.expectedOutcome && (
                              <div className="text-sm text-[#6B6B6B]">
                                Expected Outcome: {milestone.expectedOutcome}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Milestone Progress Bar */}
                        <div className="mt-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-[#6B6B6B]">Progress</span>
                            <span className="text-xs text-[#1F2937]">{milestone.progress}%</span>
                          </div>
                          <div className="bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${milestone.status === 'completed' ? 'bg-green-600' :
                                milestone.status === 'in-progress' ? 'bg-yellow-600' :
                                  'bg-gray-400'
                                }`}
                              style={{ width: `${milestone.progress}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Review DPR Button for Final DPR Preparation milestone */}
                        {milestone.isFinalDPR && (
                          <div className="mt-4">
                            <Button
                              onClick={() => handleReviewDPR(project.id)}
                              className="bg-purple-600 hover:bg-purple-700 text-white"
                              size="sm"
                            >
                              <FileText className="w-4 h-4 mr-2" />
                              Review DPR
                            </Button>
                          </div>
                        )}

                        {/* Tasks Table */}
                        {milestone.tasks && milestone.tasks.length > 0 && (
                          <div className="mt-4">
                            <div className="overflow-x-auto">
                              <table className="w-full border-collapse">
                                <thead>
                                  <tr className="border-b border-gray-200 bg-gray-50">
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Task ID</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Task Name</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Assigned To</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Deadline</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Status</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Submissions</th>
                                    <th className="text-left py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Cost</th>
                                    <th className="text-center py-2 px-3 text-xs font-semibold text-[#6B6B6B]">Take Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {milestone.tasks.map((task) => (
                                    <tr key={task.id} className="border-b border-gray-100 hover:bg-gray-50">
                                      <td className="py-3 px-3 text-sm text-[#1F2937]">{task.id}</td>
                                      <td className="py-3 px-3 text-sm text-[#1F2937]">{task.name}</td>
                                      <td className="py-3 px-3 text-sm text-[#1F2937]">{task.assignedTo}</td>
                                      <td className="py-3 px-3 text-sm text-[#1F2937]">{formatDate(task.deadline)}</td>
                                      <td className="py-3 px-3">
                                        <Badge className={`${getTaskStatusColor(task.status)} px-2 py-0.5 rounded-full text-xs`}>
                                          {task.status}
                                        </Badge>
                                      </td>
                                      <td className="py-3 px-3">
                                        {task.submissions && task.submissions.length > 0 ? (
                                          <div className="flex items-center gap-2 flex-wrap">
                                            {task.submissions.map((file) => (
                                              <div
                                                key={file.id}
                                                className="flex items-center gap-1 px-2 py-1 bg-gray-100 rounded text-xs text-[#1F2937] hover:bg-gray-200 cursor-pointer"
                                                onClick={() => toast.info(`Opening ${file.name}`)}
                                              >
                                                {file.type === 'pdf' ? (
                                                  <FileText className="w-3 h-3 text-red-600" />
                                                ) : (
                                                  <ImageIcon className="w-3 h-3 text-blue-600" />
                                                )}
                                                <span className="max-w-[100px] truncate">{file.name}</span>
                                              </div>
                                            ))}
                                          </div>
                                        ) : (
                                          <span className="text-xs text-gray-400">No submissions</span>
                                        )}
                                      </td>
                                      <td className="py-3 px-3 text-sm text-[#1F2937]">
                                        {task.cost || 'N/A'}
                                      </td>
                                      <td className="py-3 px-3">
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => handleTakeAction(project.id, milestone.id, task.id, task.name)}
                                          className="h-7 px-3 text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-300"
                                        >
                                          Take Action
                                        </Button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add Task Dialog */}
      {addTaskDialogOpen && selectedProjectId && (
        <AddTaskDialog
          open={addTaskDialogOpen}
          onOpenChange={setAddTaskDialogOpen}
          teamMembers={teamMembers}
          projectId={selectedProjectId}
          projects={projects}
          onTaskAdded={handleTaskAdded}
        />
      )}

      {/* Take Action Dialog */}
      <Dialog open={actionDialogOpen} onOpenChange={setActionDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Take Action</DialogTitle>
            <DialogDescription>
              Review and take action on task: {selectedTask?.taskName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="feedback">Feedback / Description *</Label>
              <Textarea
                id="feedback"
                placeholder="Enter your feedback or description here..."
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="min-h-32"
              />
              <p className="text-xs text-gray-500">Please provide feedback before accepting or rejecting the task.</p>
            </div>
          </div>
          <DialogFooter className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setActionDialogOpen(false);
                setFeedback('');
                setSelectedTask(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleRejectTask}
              variant="destructive"
              className="bg-red-600 hover:bg-red-700"
            >
              <X className="w-4 h-4 mr-2" />
              Reject
            </Button>
            <Button
              onClick={handleAcceptTask}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Check className="w-4 h-4 mr-2" />
              Accept
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Review DPR Dialog */}
      <Dialog open={reviewDPRDialogOpen} onOpenChange={setReviewDPRDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Review DPR</DialogTitle>
            <DialogDescription>
              Rate the DPR submission for: {projects.find(p => p.id === selectedProjectForReview)?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <StarRating
              label="1. Authenticity"
              rating={dprRatings.authenticity}
              onRatingChange={(rating) => setDprRatings({ ...dprRatings, authenticity: rating })}
            />
            <StarRating
              label="2. Use of Correct Data"
              rating={dprRatings.useOfCorrectData}
              onRatingChange={(rating) => setDprRatings({ ...dprRatings, useOfCorrectData: rating })}
            />
            <StarRating
              label="3. Technical Correctness"
              rating={dprRatings.technicalCorrectness}
              onRatingChange={(rating) => setDprRatings({ ...dprRatings, technicalCorrectness: rating })}
            />
            <StarRating
              label="4. Completeness"
              rating={dprRatings.completeness}
              onRatingChange={(rating) => setDprRatings({ ...dprRatings, completeness: rating })}
            />
            <StarRating
              label="5. Tools & Resources Used"
              rating={dprRatings.toolsAndResourcesUsed}
              onRatingChange={(rating) => setDprRatings({ ...dprRatings, toolsAndResourcesUsed: rating })}
            />
          </div>
          <DialogFooter className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setReviewDPRDialogOpen(false);
                setSelectedProjectForReview(null);
                setDprRatings({
                  authenticity: 0,
                  useOfCorrectData: 0,
                  technicalCorrectness: 0,
                  completeness: 0,
                  toolsAndResourcesUsed: 0,
                });
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitDPRReview}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Submit Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
