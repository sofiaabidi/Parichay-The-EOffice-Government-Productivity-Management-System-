import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ScrollArea } from '../ui/scroll-area';
import { toast } from 'sonner@2.0.3';

interface AddProjectVisitModalProps {
  open: boolean;
  onClose: () => void;
}

interface Employee {
  id: string;
  name: string;
  avatar: string;
}

interface Project {
  id: string;
  name: string;
}

const projects: Project[] = [
  { id: '1', name: 'Highway Expansion Project - NH-44' },
  { id: '2', name: 'Urban Infrastructure Development - Phase 1' },
  { id: '3', name: 'Bridge Construction - River Ganga' },
  { id: '4', name: 'Smart City Road Network' },
  { id: '5', name: 'Rural Connectivity Initiative' },
  { id: '6', name: 'Metro Rail Extension - Line 2' },
  { id: '7', name: 'Water Supply Pipeline Project' },
  { id: '8', name: 'Sewage Treatment Plant - Zone A' },
  { id: '9', name: 'Solar Power Plant Installation' },
  { id: '10', name: 'Hospital Building Construction' },
];

const employees: Employee[] = [
  { id: '1', name: 'Rajesh Kumar', avatar: 'RK' },
  { id: '2', name: 'Priya Sharma', avatar: 'PS' },
  { id: '3', name: 'Amit Patel', avatar: 'AP' },
  { id: '4', name: 'Sneha Reddy', avatar: 'SR' },
  { id: '5', name: 'Vikram Singh', avatar: 'VS' },
  { id: '6', name: 'Anita Desai', avatar: 'AD' },
  { id: '7', name: 'Rahul Gupta', avatar: 'RG' },
  { id: '8', name: 'Kavita Nair', avatar: 'KN' },
  { id: '9', name: 'Sanjay Mehta', avatar: 'SM' },
  { id: '10', name: 'Deepa Iyer', avatar: 'DI' },
];

export function AddProjectVisitModal({ open, onClose }: AddProjectVisitModalProps) {
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [scores, setScores] = useState<Record<string, string>>({});

  const handleScoreChange = (employeeId: string, score: string) => {
    setScores(prev => ({ ...prev, [employeeId]: score }));
  };

  const handleSubmit = () => {
    if (!selectedProject) {
      toast.error('Please select a project');
      return;
    }
    const filledScores = Object.values(scores).filter(s => s !== '').length;
    if (filledScores === 0) {
      toast.error('Please enter at least one score');
      return;
    }
    toast.success('Project visit scores recorded successfully');
    handleClose();
  };

  const handleClose = () => {
    setSelectedProject('');
    setScores({});
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-white">
        <DialogHeader>
          <DialogTitle className="text-[#1F2937]">Record Project Visit Scores</DialogTitle>
        </DialogHeader>

        <div className="space-y-2 py-4">
          <Label htmlFor="project-select" className="text-[#1F2937]">Select Project</Label>
          <Select value={selectedProject} onValueChange={setSelectedProject}>
            <SelectTrigger id="project-select" className="w-full border-gray-300">
              <SelectValue placeholder="Choose a project" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3 py-4">
            {employees.map((employee) => (
              <div
                key={employee.id}
                className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:shadow-sm transition-shadow"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#F3F4F6] flex items-center justify-center">
                    <span className="text-[#1F2937] text-sm">{employee.avatar}</span>
                  </div>
                  <span className="text-[#1F2937]">{employee.name}</span>
                </div>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  placeholder="Score"
                  value={scores[employee.id] || ''}
                  onChange={(e) => handleScoreChange(employee.id, e.target.value)}
                  className="w-24 border-gray-300"
                />
              </div>
            ))}
          </div>
        </ScrollArea>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-[#1F2937] hover:bg-gray-800 text-white">
            Submit
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
