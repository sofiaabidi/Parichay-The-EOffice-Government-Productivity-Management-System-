import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { Calendar } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { toast } from 'sonner';

interface AddSurveyModalProps {
  open: boolean;
  onClose: () => void;
}

interface TeamMember {
  id: number;
  name: string;
  email: string;
  designation?: string;
  role?: string;
}

export function AddSurveyModal({ open, onClose }: AddSurveyModalProps) {
  const [surveyTitle, setSurveyTitle] = useState('');
  const [totalArea, setTotalArea] = useState('');
  const [expectedTime, setExpectedTime] = useState('');
  const [deadline, setDeadline] = useState<Date | undefined>(undefined);
  const [selectedMembers, setSelectedMembers] = useState<number[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);

  // Load team members when modal opens
  useEffect(() => {
    if (open) {
      // Load team members (dummy data for now)
      setTeamMembers([
        { id: 1, name: 'Rajesh Kumar', email: 'rajesh@example.com', designation: 'Field Engineer' },
        { id: 2, name: 'Priya Sharma', email: 'priya@example.com', designation: 'Surveyor' },
        { id: 3, name: 'Amit Patel', email: 'amit@example.com', designation: 'Site Supervisor' },
        { id: 4, name: 'Sneha Reddy', email: 'sneha@example.com', designation: 'Project Coordinator' },
        { id: 5, name: 'Vikram Singh', email: 'vikram@example.com', designation: 'Field Engineer' },
      ]);
    }
  }, [open]);

  const handleMemberToggle = (memberId: number) => {
    setSelectedMembers((prev) =>
      prev.includes(memberId)
        ? prev.filter((id) => id !== memberId)
        : [...prev, memberId]
    );
  };

  const handleSubmit = () => {
    if (!surveyTitle || !totalArea || !expectedTime || !deadline) {
      toast.error('Please fill in all fields');
      return;
    }
    toast.success('Survey Created Successfully');
    handleClose();
  };

  const handleClose = () => {
    setSurveyTitle('');
    setTotalArea('');
    setExpectedTime('');
    setDeadline(undefined);
    setSelectedMembers([]);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#1F2937]">Initiate New Survey</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="surveyTitle" className="text-[#1F2937]">Survey Title</Label>
            <Input
              id="surveyTitle"
              placeholder="Enter Survey Title"
              value={surveyTitle}
              onChange={(e) => setSurveyTitle(e.target.value)}
              className="border-gray-300"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="totalArea" className="text-[#1F2937]">Total Area (Sq Km/Acres)</Label>
            <Input
              id="totalArea"
              type="number"
              placeholder="Enter total area"
              value={totalArea}
              onChange={(e) => setTotalArea(e.target.value)}
              className="border-gray-300"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="expectedTime" className="text-[#1F2937]">Expected Time (Hours/Days)</Label>
            <Input
              id="expectedTime"
              type="number"
              placeholder="Enter expected time"
              value={expectedTime}
              onChange={(e) => setExpectedTime(e.target.value)}
              className="border-gray-300"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="deadline" className="text-[#1F2937]">Deadline</Label>
            <Popover>
              <PopoverTrigger asChild>
                <div className="flex items-center gap-2">
                  <Input
                    id="deadline"
                    placeholder="Select deadline"
                    value={deadline ? deadline.toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    }) : ''}
                    readOnly
                    className="border-gray-300 flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="border-gray-300"
                  >
                    <CalendarIcon className="w-4 h-4" />
                  </Button>
                </div>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={deadline}
                  onSelect={setDeadline}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label className="text-[#1F2937]">Survey Members</Label>
            <div className="border border-gray-200 rounded-md p-4 max-h-60 overflow-y-auto bg-[#F3F4F6]">
              {teamMembers.length === 0 ? (
                <div className="text-sm text-gray-500 text-center py-4">No team members found</div>
              ) : (
                <div className="space-y-3">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="flex items-center space-x-3 bg-white p-3 rounded-lg border border-gray-200">
                      <Checkbox
                        id={`member-${member.id}`}
                        checked={selectedMembers.includes(member.id)}
                        onCheckedChange={() => handleMemberToggle(member.id)}
                      />
                      <label
                        htmlFor={`member-${member.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1"
                      >
                        <div className="font-medium text-[#1F2937]">{member.name}</div>
                        <div className="text-xs text-gray-500">
                          {member.designation || member.role || 'Employee'}
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {selectedMembers.length > 0 && (
              <p className="text-xs text-gray-500">
                {selectedMembers.length} member{selectedMembers.length !== 1 ? 's' : ''} selected
              </p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-[#1F2937] hover:bg-gray-800 text-white">
            Submit
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
