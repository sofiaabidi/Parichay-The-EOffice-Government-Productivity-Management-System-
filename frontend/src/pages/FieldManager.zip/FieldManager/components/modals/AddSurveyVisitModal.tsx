import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ScrollArea } from '../ui/scroll-area';
import { toast } from 'sonner@2.0.3';

interface AddSurveyVisitModalProps {
  open: boolean;
  onClose: () => void;
}

interface Employee {
  id: string;
  name: string;
  avatar: string;
}

interface Survey {
  id: string;
  name: string;
}

const surveys: Survey[] = [
  { id: '1', name: 'Land Survey - Industrial Zone A' },
  { id: '2', name: 'Topographic Survey - Residential Area B' },
  { id: '3', name: 'Boundary Survey - Commercial District' },
  { id: '4', name: 'Construction Site Survey - Project Alpha' },
  { id: '5', name: 'Environmental Impact Survey - Forest Area' },
  { id: '6', name: 'Traffic Flow Survey - City Center' },
  { id: '7', name: 'Soil Testing Survey - Agricultural Land' },
  { id: '8', name: 'Water Quality Survey - River Basin' },
  { id: '9', name: 'Population Census Survey - Ward 5' },
  { id: '10', name: 'Infrastructure Assessment Survey' },
];

const employees: Employee[] = [
  { id: '1', name: 'Rajesh Kumar', avatar: 'RK' },
  { id: '2', name: 'Priya Sharma', avatar: 'PS' },
  { id: '3', name: 'Amit Patel', avatar: 'AP' },
  { id: '4', name: 'Sneha Reddy', avatar: 'SR' },
  { id: '5', name: 'Vikram Singh', avatar: 'VS' },
  { id: '6', name: 'Anita Desai', avatar: 'AD' },
  { id: '7', name: 'Rahul Gupta', avatar: 'RG' },
  { id: '8', name: 'Kavita Nair', avatar: 'KN' },
  { id: '9', name: 'Sanjay Mehta', avatar: 'SM' },
  { id: '10', name: 'Deepa Iyer', avatar: 'DI' },
];

export function AddSurveyVisitModal({ open, onClose }: AddSurveyVisitModalProps) {
  const [selectedSurvey, setSelectedSurvey] = useState<string>('');
  const [scores, setScores] = useState<Record<string, string>>({});

  const handleScoreChange = (employeeId: string, score: string) => {
    setScores(prev => ({ ...prev, [employeeId]: score }));
  };

  const handleSubmit = () => {
    if (!selectedSurvey) {
      toast.error('Please select a survey');
      return;
    }
    const filledScores = Object.values(scores).filter(s => s !== '').length;
    if (filledScores === 0) {
      toast.error('Please enter at least one score');
      return;
    }
    toast.success('Survey visit scores recorded successfully');
    handleClose();
  };

  const handleClose = () => {
    setSelectedSurvey('');
    setScores({});
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-white">
        <DialogHeader>
          <DialogTitle className="text-[#1F2937]">Record Survey Visit Scores</DialogTitle>
        </DialogHeader>

        <div className="space-y-2 py-4">
          <Label htmlFor="survey-select" className="text-[#1F2937]">Select Survey</Label>
          <Select value={selectedSurvey} onValueChange={setSelectedSurvey}>
            <SelectTrigger id="survey-select" className="w-full border-gray-300">
              <SelectValue placeholder="Choose a survey" />
            </SelectTrigger>
            <SelectContent>
              {surveys.map((survey) => (
                <SelectItem key={survey.id} value={survey.id}>
                  {survey.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3 py-4">
            {employees.map((employee) => (
              <div
                key={employee.id}
                className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:shadow-sm transition-shadow"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#F3F4F6] flex items-center justify-center">
                    <span className="text-[#1F2937] text-sm">{employee.avatar}</span>
                  </div>
                  <span className="text-[#1F2937]">{employee.name}</span>
                </div>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  placeholder="Score"
                  value={scores[employee.id] || ''}
                  onChange={(e) => handleScoreChange(employee.id, e.target.value)}
                  className="w-24 border-gray-300"
                />
              </div>
            ))}
          </div>
        </ScrollArea>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-[#1F2937] hover:bg-gray-800 text-white">
            Submit
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
