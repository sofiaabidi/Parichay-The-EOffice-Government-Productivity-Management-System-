import { Star } from 'lucide-react';
import { Button } from './ui/button';

interface Feedback {
  id: string;
  name: string;
  role: string;
  date: string;
  subject: string;
  comment: string;
  rating: number;
  avatar: string;
  avatarColor: string;
}

const feedbacks: Feedback[] = [
  {
    id: '1',
    name: 'Rajesh Kumar',
    role: 'Manager',
    date: 'Sep 28, 2025',
    subject: 'Re: Quarterly Budget Report',
    comment: 'Excellent work on the budget analysis. Very detailed and presented well ahead of deadline.',
    rating: 5,
    avatar: 'RK',
    avatarColor: 'bg-pink-100 text-pink-600',
  },
  {
    id: '2',
    name: 'Priya Sharma',
    role: 'Team Lead',
    date: 'Sep 25, 2025',
    subject: 'Re: Stakeholder Coordination',
    comment: 'Good coordination with stakeholders. Communication could be more frequent.',
    rating: 3.5,
    avatar: 'PS',
    avatarColor: 'bg-purple-100 text-purple-600',
  },
  {
    id: '3',
    name: 'Amit Patel',
    role: 'Peer',
    date: 'Sep 20, 2025',
    subject: 'Re: Document Review',
    comment: 'Very thorough review with constructive suggestions. Great collaboration!',
    rating: 4.5,
    avatar: 'AP',
    avatarColor: 'bg-blue-100 text-blue-600',
  },
  {
    id: '4',
    name: 'Sunita Reddy',
    role: 'Manager',
    date: 'Sep 15, 2025',
    subject: 'Re: Policy Implementation',
    comment: 'Good implementation of the new policy framework. A few minor adjustments needed in the documentation section.',
    rating: 3.5,
    avatar: 'SR',
    avatarColor: 'bg-blue-100 text-blue-600',
  },
];

// Calculate average rating
const averageRating = feedbacks.reduce((sum, f) => sum + f.rating, 0) / feedbacks.length;

// Star rating component with half-star support
function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => {
        const starValue = i + 1;
        if (rating >= starValue) {
          // Full star
          return (
            <Star
              key={i}
              className="w-4 h-4 fill-yellow-400 text-yellow-400"
            />
          );
        } else if (rating >= starValue - 0.5) {
          // Half star
          return (
            <div key={i} className="relative w-4 h-4 inline-block">
              <Star className="w-4 h-4 fill-gray-200 text-gray-200" />
              <div className="absolute left-0 top-0 overflow-hidden" style={{ width: '50%' }}>
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              </div>
            </div>
          );
        } else {
          // Empty star
          return (
            <Star
              key={i}
              className="w-4 h-4 fill-gray-200 text-gray-200"
            />
          );
        }
      })}
    </div>
  );
}

export function FeedbackSection() {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-[#1F2937] text-xl font-semibold">Feedback Received</h2>
        <div className="flex items-center gap-4">
          {/* Average Rating Box */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-4 py-2 flex items-center gap-2">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-[#1F2937] font-semibold">{averageRating.toFixed(1)} Average</span>
          </div>
          {/* Reviews Count Button */}
          <Button variant="outline" className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100">
            {feedbacks.length} Reviews
          </Button>
        </div>
      </div>

      {/* Feedback Cards Grid */}
      <div className="grid grid-cols-2 gap-4">
        {feedbacks.map((feedback) => (
          <div
            key={feedback.id}
            className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start gap-3 mb-3">
              <div className={`w-10 h-10 rounded-full ${feedback.avatarColor} flex items-center justify-center flex-shrink-0`}>
                <span className="text-sm font-semibold">{feedback.avatar}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[#1F2937] font-medium">{feedback.name}, {feedback.role}</p>
                <p className="text-sm text-gray-500">{feedback.date}</p>
              </div>
            </div>
            <p className="text-[#1F2937] font-medium text-sm mb-2">{feedback.subject}</p>
            <p className="text-[#1F2937] text-sm leading-relaxed mb-3">{feedback.comment}</p>
            <StarRating rating={feedback.rating} />
          </div>
        ))}
      </div>
    </div>
  );
}
