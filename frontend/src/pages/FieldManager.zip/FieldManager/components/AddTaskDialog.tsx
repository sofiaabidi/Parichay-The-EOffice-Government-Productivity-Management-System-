import React, { useState, useEffect } from "react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { toast } from "sonner";

interface TeamMember {
  id: number;
  name: string;
  email: string;
  role?: string;
  designation?: string;
}

interface Project {
  id: number;
  name: string;
  milestones?: Array<{
    id: number;
    name: string;
    status: string;
  }>;
}

interface AddTaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  teamMembers: TeamMember[];
  projectId: number;
  projects: Project[];
  onTaskAdded?: () => void;
}

export function AddTaskDialog({
  open,
  onOpenChange,
  teamMembers,
  projectId,
  projects,
  onTaskAdded,
}: AddTaskDialogProps) {
  const [loading, setLoading] = useState(false);
  const [taskData, setTaskData] = useState({
    taskName: "",
    deadline: "",
    assignedTo: "",
    expectedOutcome: "",
    milestoneId: "",
    budget: "",
  });

  const currentProject = projects.find((p) => p.id === projectId);
  const milestones = currentProject?.milestones || [];

  useEffect(() => {
    if (!open) {
      // Reset form when dialog closes
      setTaskData({
        taskName: "",
        deadline: "",
        assignedTo: "",
        expectedOutcome: "",
        milestoneId: "",
        budget: "",
      });
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!taskData.taskName || !taskData.assignedTo || !taskData.deadline) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      setLoading(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Using dummy data - no actual API call
      const assignedMember = teamMembers.find(
        (m) => m.id === Number(taskData.assignedTo)
      );
      toast.success(
        `Task "${taskData.taskName}" assigned to ${assignedMember?.name || "team member"}`
      );

      setTaskData({
        taskName: "",
        deadline: "",
        assignedTo: "",
        expectedOutcome: "",
        milestoneId: "",
        budget: "",
      });
      onOpenChange(false);

      if (onTaskAdded) {
        onTaskAdded();
      }
    } catch (error: any) {
      toast.error(
        error.response?.data?.message || "Failed to create task"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Add New Task</DialogTitle>
          <DialogDescription>
            Create a new task for the project. Fill in the details below.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3 mt-3">
          <div className="space-y-1.5">
            <Label htmlFor="taskName">Task Name *</Label>
            <Input
              id="taskName"
              placeholder="Enter task name"
              value={taskData.taskName}
              onChange={(e) =>
                setTaskData({ ...taskData, taskName: e.target.value })
              }
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="deadline">Deadline *</Label>
            <Input
              id="deadline"
              type="date"
              value={taskData.deadline}
              onChange={(e) =>
                setTaskData({ ...taskData, deadline: e.target.value })
              }
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="members">Members *</Label>
            <Select
              value={taskData.assignedTo}
              onValueChange={(value) =>
                setTaskData({ ...taskData, assignedTo: value })
              }
              required
            >
              <SelectTrigger id="members">
                <SelectValue placeholder="Select team member" />
              </SelectTrigger>
              <SelectContent>
                {teamMembers.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No team members available
                  </SelectItem>
                ) : (
                  teamMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id.toString()}>
                      {member.name} - {member.designation || member.role || "Employee"}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="expectedOutcome">Expected Outcome Description</Label>
            <Textarea
              id="expectedOutcome"
              placeholder="Describe the expected outcome of this task"
              rows={4}
              value={taskData.expectedOutcome}
              onChange={(e) =>
                setTaskData({ ...taskData, expectedOutcome: e.target.value })
              }
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="milestone">Under What Milestone</Label>
            <Select
              value={taskData.milestoneId}
              onValueChange={(value) =>
                setTaskData({ ...taskData, milestoneId: value })
              }
            >
              <SelectTrigger id="milestone">
                <SelectValue placeholder="Select a milestone (optional)" />
              </SelectTrigger>
              <SelectContent>
                {milestones.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No milestones available
                  </SelectItem>
                ) : (
                  milestones.map((milestone) => (
                    <SelectItem key={milestone.id} value={milestone.id.toString()}>
                      {milestone.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="budget">Budget</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
              <Input
                id="budget"
                type="number"
                placeholder="Enter budget"
                value={taskData.budget}
                onChange={(e) =>
                  setTaskData({ ...taskData, budget: e.target.value })
                }
                className="pl-8"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700"
              disabled={loading}
            >
              {loading ? "Creating..." : "Add Task"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

