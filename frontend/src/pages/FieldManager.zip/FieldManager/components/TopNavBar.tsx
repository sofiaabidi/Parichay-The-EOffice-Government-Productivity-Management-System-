import { useState, useEffect } from 'react';
import { Calendar, LogOut, Pencil, Bell } from 'lucide-react';
import { Button } from './ui/button';
import { CalendarModal } from './CalendarModal';
import { EmployeeFeedbackDialog } from './EmployeeFeedbackDialog';
import { NotificationModal } from './NotificationModal';
import { useAuth } from '../../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface TopNavBarProps {
  totalTime: string;
  isCheckedIn: boolean;
  onCheckIn: () => void;
  onCheckOut: () => void;
}

export function TopNavBar({ totalTime, isCheckedIn, onCheckIn, onCheckOut }: TopNavBarProps) {

  const [showCalendar, setShowCalendar] = useState(false);
  const [showEmployeeFeedback, setShowEmployeeFeedback] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [time, setTime] = useState('00:00');
  const [startTime, setStartTime] = useState<number | null>(null);

  // ⭐ ADD AUTH + NAVIGATION
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();            // clear user + token
    localStorage.clear();// clear remembered user
    navigate("/");       // redirect to login
  };

  useEffect(() => {
    if (!isCheckedIn) {
      setStartTime(null);
      setTime('00:00');
      return;
    }

    setStartTime(Date.now());
    const interval = setInterval(() => {
      if (startTime) {
        const elapsed = Date.now() - startTime;
        const hours = Math.floor(elapsed / 3600000);
        const minutes = Math.floor((elapsed % 3600000) / 60000);
        setTime(`${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isCheckedIn, startTime]);

  return (
    <>
      <nav className="w-full bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-[1600px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">

            {/* Left - Logo */}
            <div className="flex items-center gap-3">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <rect width="32" height="32" rx="6" fill="#1F2937" />
                <path d="M16 8L22 12V20L16 24L10 20V12L16 8Z" stroke="white" strokeWidth="2" />
                <circle cx="16" cy="16" r="3" fill="white" />
              </svg>
              <h1 className="text-[#1F2937]">Field Manager Dashboard</h1>
            </div>

            {/* Center */}
            <div className="flex items-center gap-4">
              {!isCheckedIn ? (
                <Button 
                  onClick={onCheckIn}
                  className="bg-green-600 hover:bg-green-700 text-white rounded-full px-6"
                >
                  Check In
                </Button>
              ) : (
                <Button 
                  onClick={onCheckOut}
                  className="bg-black hover:bg-gray-800 text-white rounded-full px-6"
                >
                  Check Out
                </Button>
              )}

              <span className="text-[#1F2937]">Total Time: {time} hrs</span>

              {/* Employee Feedback (Pencil Icon) */}
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowEmployeeFeedback(true)}
                className="text-[#1F2937]"
              >
                <Pencil className="w-5 h-5" />
              </Button>

              {/* Notification Icon */}
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowNotifications(true)}
                className="text-[#1F2937] relative"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>

              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowCalendar(true)}
                className="text-[#1F2937]"
              >
                <Calendar className="w-5 h-5" />
              </Button>
            </div>

            {/* Right - Profile + ⭐ LOGOUT */}
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-[#1F2937]">John Manager</p>
                <p className="text-gray-500 text-sm">Field Manager</p>
                <p className="text-gray-500 text-sm">ID: FM-2025-001</p>
              </div>

              <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
                <span className="text-[#1F2937]">JM</span>
              </div>

              {/* ⭐ LOGOUT BUTTON WITH LOGIC ADDED */}
              <Button
                variant="ghost"
                size="icon"
                className="text-[#1F2937]"
                onClick={handleLogout}
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <CalendarModal open={showCalendar} onClose={() => setShowCalendar(false)} />
      <EmployeeFeedbackDialog
        open={showEmployeeFeedback}
        onOpenChange={setShowEmployeeFeedback}
      />
      <NotificationModal open={showNotifications} onClose={() => setShowNotifications(false)} />
    </>
  );
}

