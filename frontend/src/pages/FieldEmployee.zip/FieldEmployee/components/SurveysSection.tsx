import { useState } from 'react';
import { MapPin, Clock, CheckCircle, Upload, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import SurveySubmitModal from './SurveySubmitModal';

export default function SurveysSection() {
  const [submitModalOpen, setSubmitModalOpen] = useState(false);
  const [selectedSurvey, setSelectedSurvey] = useState<any>(null);

  const surveys = [
    {
      id: 1,
      name: 'Agricultural Land Survey – Block 5',
      status: 'approved',
      area: '45 hectares',
      estimatedTime: '6 hours',
      surveyAccuracy: 95,
      areaCovered: '45 hectares',
      timeTaken: '5.5 hours',
      managerRemarks: 'Excellent accuracy and detailed documentation. Survey data meets all standards.',
      submittedDate: '2024-11-10',
    },
    {
      id: 2,
      name: 'Road Width Verification – Highway 23',
      status: 'submitted',
      area: '12 km stretch',
      estimatedTime: '4 hours',
      areaCovered: '12 km',
      timeTaken: '4.2 hours',
      submittedDate: '2024-11-20',
    },
    {
      id: 3,
      name: 'Forest Area Demarcation',
      status: 'pending',
      area: '120 hectares',
      estimatedTime: '8 hours',
      deadline: '2024-11-30',
    },
    {
      id: 4,
      name: 'Water Body Mapping – Zone 3',
      status: 'pending',
      area: '30 hectares',
      estimatedTime: '5 hours',
      deadline: '2024-12-05',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'submitted':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'pending':
        return 'bg-orange-100 text-orange-700 border-orange-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const handleSubmitSurvey = (survey: any) => {
    setSelectedSurvey(survey);
    setSubmitModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-[#1C1C28] text-xl">My Surveys</h2>
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
          {surveys.filter(s => s.status === 'approved').length} Approved
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {surveys.map((survey) => (
          <div
            key={survey.id}
            className={`bg-white rounded-xl shadow-sm p-6 border-l-4 ${
              survey.status === 'approved'
                ? 'border-l-green-500'
                : survey.status === 'submitted'
                ? 'border-l-blue-500'
                : 'border-l-orange-500'
            }`}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-[#1C1C28] mb-2">{survey.name}</h3>
                <Badge className={getStatusColor(survey.status)} variant="outline">
                  {survey.status}
                </Badge>
              </div>
            </div>

            {/* Survey Details */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="size-4 text-gray-400" />
                <span className="text-[#6B6B6B]">Area: </span>
                <span className="text-[#1C1C28]">{survey.area}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="size-4 text-gray-400" />
                <span className="text-[#6B6B6B]">Estimated Time: </span>
                <span className="text-[#1C1C28]">{survey.estimatedTime}</span>
              </div>
              {survey.deadline && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="size-4 text-orange-400" />
                  <span className="text-[#6B6B6B]">Deadline: </span>
                  <span className="text-orange-600">{survey.deadline}</span>
                </div>
              )}
            </div>

            {/* Approved Survey Details */}
            {survey.status === 'approved' && (
              <div className="space-y-3 p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="size-5 text-green-600" />
                  <span className="text-green-700">Survey Approved</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-[#6B6B6B]">Survey Accuracy</div>
                    <div className="text-[#1C1C28] text-lg">{survey.surveyAccuracy}%</div>
                  </div>
                  <div>
                    <div className="text-[#6B6B6B]">Area Covered</div>
                    <div className="text-[#1C1C28] text-lg">{survey.areaCovered}</div>
                  </div>
                  <div>
                    <div className="text-[#6B6B6B]">Time Taken</div>
                    <div className="text-[#1C1C28] text-lg">{survey.timeTaken}</div>
                  </div>
                  <div>
                    <div className="text-[#6B6B6B]">Submitted</div>
                    <div className="text-[#1C1C28] text-lg">{survey.submittedDate}</div>
                  </div>
                </div>
                <div className="pt-3 border-t border-green-200">
                  <div className="text-[#6B6B6B] text-sm mb-1">Manager Remarks</div>
                  <div className="text-[#1C1C28] text-sm">{survey.managerRemarks}</div>
                </div>
              </div>
            )}

            {/* Submitted Survey Details */}
            {survey.status === 'submitted' && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-blue-700 mb-3">Pending Manager Review</div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-[#6B6B6B]">Area Covered</div>
                    <div className="text-[#1C1C28]">{survey.areaCovered}</div>
                  </div>
                  <div>
                    <div className="text-[#6B6B6B]">Time Taken</div>
                    <div className="text-[#1C1C28]">{survey.timeTaken}</div>
                  </div>
                </div>
                <div className="mt-2 text-xs text-[#6B6B6B]">
                  Submitted: {survey.submittedDate}
                </div>
              </div>
            )}

            {/* Pending Survey - Action Button */}
            {survey.status === 'pending' && (
              <Button
                onClick={() => handleSubmitSurvey(survey)}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                <Upload className="size-4 mr-2" />
                Submit Survey Data
              </Button>
            )}

            {/* View Details Button for Approved/Submitted */}
            {(survey.status === 'approved' || survey.status === 'submitted') && (
              <Button variant="outline" className="w-full mt-4">
                <FileText className="size-4 mr-2" />
                View Survey Details
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Survey Submit Modal */}
      {submitModalOpen && selectedSurvey && (
        <SurveySubmitModal
          survey={selectedSurvey}
          onClose={() => setSubmitModalOpen(false)}
        />
      )}
    </div>
  );
}
