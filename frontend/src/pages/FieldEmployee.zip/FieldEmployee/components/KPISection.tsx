import { TrendingUp, Clock, Target, BarChart3 } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

export default function KPISection() {
  // KPI breakdown data for pie chart
  const kpiBreakdownData = [
    { name: 'Timeliness of DPR', value: 85, color: '#3B82F6' },
    { name: 'Quality of DPR', value: 90, color: '#10B981' },
    { name: 'Survey accuracy', value: 78, color: '#F59E0B' },
    { name: 'Project timelines', value: 82, color: '#8B5CF6' },
    { name: 'Expenditure vs targets', value: 75, color: '#EF4444' },
    { name: 'Physical progress', value: 88, color: '#06B6D4' },
    { name: 'Technical standards', value: 92, color: '#14B8A6' },
  ];

  // Monthly KPI trend data
  const monthlyTrendData = [
    { month: 'May', score: 78 },
    { month: 'Jun', score: 81 },
    { month: 'Jul', score: 79 },
    { month: 'Aug', score: 84 },
    { month: 'Sep', score: 86 },
    { month: 'Oct', score: 85 },
    { month: 'Nov', score: 87 },
  ];

  const overallScore = 87;
  const circumference = 2 * Math.PI * 70;
  const progress = (overallScore / 100) * circumference;

  return (
    <div className="space-y-6">
      {/* Top Section - Overall Performance + Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Overall Performance Circle */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-[#1C1C28] mb-4">Overall Performance</h3>
          <div className="flex items-center justify-center">
            <div className="relative size-44">
              <svg className="transform -rotate-90" width="176" height="176">
                <circle
                  cx="88"
                  cy="88"
                  r="70"
                  stroke="#E5E7EB"
                  strokeWidth="12"
                  fill="none"
                />
                <circle
                  cx="88"
                  cy="88"
                  r="70"
                  stroke="#10B981"
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference - progress}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-4xl text-[#1C1C28]">{overallScore}</div>
                <div className="text-[#6B6B6B] text-sm">/ 100</div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          {/* Task Completion */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-start justify-between mb-3">
              <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                <Target className="size-6" />
              </div>
            </div>
            <div className="text-3xl text-[#1C1C28] mb-1">78%</div>
            <div className="text-[#6B6B6B]">Task Completion</div>
            <div className="mt-3 bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '78%' }}></div>
            </div>
          </div>

          {/* Technical Compliance */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-start justify-between mb-3">
              <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                <BarChart3 className="size-6" />
              </div>
            </div>
            <div className="text-3xl text-[#1C1C28] mb-1">92%</div>
            <div className="text-[#6B6B6B]">Technical Compliance</div>
            <div className="mt-3 bg-gray-200 rounded-full h-2">
              <div className="bg-green-600 h-2 rounded-full" style={{ width: '92%' }}></div>
            </div>
          </div>

          {/* Avg Task Duration */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-start justify-between mb-3">
              <div className="bg-orange-100 text-orange-600 p-3 rounded-lg">
                <Clock className="size-6" />
              </div>
            </div>
            <div className="text-3xl text-[#1C1C28] mb-1">2.4hrs</div>
            <div className="text-[#6B6B6B]">Avg Task Duration</div>
            <div className="text-sm text-green-600 mt-2">↓ 15% from last month</div>
          </div>

          {/* Utilization Rate */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-start justify-between mb-3">
              <div className="bg-purple-100 text-purple-600 p-3 rounded-lg">
                <TrendingUp className="size-6" />
              </div>
            </div>
            <div className="text-3xl text-[#1C1C28] mb-1">85%</div>
            <div className="text-[#6B6B6B]">Utilization Rate</div>
            <div className="mt-3 bg-gray-200 rounded-full h-2">
              <div className="bg-purple-600 h-2 rounded-full" style={{ width: '85%' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section - KPI Breakdown Pie Chart + Monthly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* KPI Breakdown Pie Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-[#1C1C28] mb-4">KPI Breakdown</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={kpiBreakdownData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${value}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {kpiBreakdownData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {kpiBreakdownData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div
                  className="size-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-sm text-[#6B6B6B]">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Monthly KPI Trend */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-[#1C1C28] mb-4">Monthly KPI Trend</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis
                  dataKey="month"
                  stroke="#6B6B6B"
                  style={{ fontSize: '12px' }}
                />
                <YAxis
                  stroke="#6B6B6B"
                  style={{ fontSize: '12px' }}
                  domain={[0, 100]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#3B82F6"
                  strokeWidth={3}
                  dot={{ fill: '#3B82F6', r: 5 }}
                  activeDot={{ r: 7 }}
                  name="KPI Score"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
