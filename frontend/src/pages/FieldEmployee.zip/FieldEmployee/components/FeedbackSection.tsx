import { Star } from 'lucide-react';
import { Badge } from './ui/badge';

export default function FeedbackSection() {
  const receivedFeedbacks = [
    {
      id: 1,
      from: 'Rajesh Kumar',
      initials: 'RK',
      role: 'Manager',
      subject: 'Re: Quarterly Budget Report',
      message: 'Excellent work on the budget analysis. Very detailed and presented well ahead of deadline.',
      date: 'Sep 28, 2025',
      rating: 5,
    },
    {
      id: 2,
      from: 'Priya Sharma',
      initials: 'PS',
      role: 'Team Lead',
      subject: 'Re: Stakeholder Coordination',
      message: 'Good coordination with stakeholders. Communication could be more frequent.',
      date: 'Sep 25, 2025',
      rating: 4,
    },
    {
      id: 3,
      from: 'Amit Patel',
      initials: 'AP',
      role: 'Peer',
      subject: 'Re: Document Review',
      message: 'Very thorough review with constructive suggestions. Great collaboration!',
      date: 'Sep 20, 2025',
      rating: 5,
    },
    {
      id: 4,
      from: 'Sunita Reddy',
      initials: 'SR',
      role: 'Manager',
      subject: 'Re: Policy Implementation',
      message: 'Good implementation of the new policy framework. A few minor adjustments needed in the documentation section.',
      date: 'Sep 15, 2025',
      rating: 4,
    },
  ];

  // Calculate average rating
  const averageRating = (
    receivedFeedbacks.reduce((sum, feedback) => sum + feedback.rating, 0) /
    receivedFeedbacks.length
  ).toFixed(1);

  const getAvatarColor = (initials: string) => {
    const colors = [
      'bg-blue-500',
      'bg-green-500',
      'bg-purple-500',
      'bg-orange-500',
      'bg-pink-500',
      'bg-indigo-500',
    ];
    const index = initials.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-[#1C1C28] text-xl">Feedback Received</h2>
          <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-300 rounded-full px-4 py-2">
            <Star className="size-5 text-yellow-500 fill-yellow-500" />
            <span className="text-[#1C1C28]">{averageRating}</span>
            <span className="text-[#6B6B6B] text-sm">Average</span>
          </div>
        </div>
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
          {receivedFeedbacks.length} Reviews
        </Badge>
      </div>

      {/* Feedback Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {receivedFeedbacks.map((feedback) => (
          <div
            key={feedback.id}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:shadow-md transition-all"
          >
            {/* Header with Avatar and Info */}
            <div className="flex items-start gap-4 mb-4">
              {/* Avatar */}
              <div
                className={`size-12 rounded-full ${getAvatarColor(
                  feedback.initials
                )} text-white flex items-center justify-center shrink-0`}
              >
                <span>{feedback.initials}</span>
              </div>

              {/* Name, Role, and Date */}
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-[#1C1C28]">{feedback.from}</h3>
                    <p className="text-[#6B6B6B] text-sm">• {feedback.role}</p>
                  </div>
                  <span className="text-xs text-[#9CA3AF]">{feedback.date}</span>
                </div>
              </div>
            </div>

            {/* Subject */}
            <div className="text-[#1C1C28] mb-3">{feedback.subject}</div>

            {/* Message */}
            <p className="text-[#6B6B6B] mb-4">{feedback.message}</p>

            {/* Star Rating */}
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`size-5 ${
                    star <= feedback.rating
                      ? 'text-yellow-400 fill-yellow-400'
                      : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Empty State (if no feedback) */}
      {receivedFeedbacks.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <Star className="size-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-[#1C1C28] mb-2">No Feedback Yet</h3>
          <p className="text-[#6B6B6B]">
            You haven't received any feedback from your colleagues.
          </p>
        </div>
      )}
    </div>
  );
}
