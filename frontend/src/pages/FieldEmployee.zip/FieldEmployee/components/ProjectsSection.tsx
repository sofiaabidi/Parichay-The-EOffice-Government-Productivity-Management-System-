import { useState } from 'react';
import { ChevronDown, ChevronUp, Upload, FileText, Image as ImageIcon, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import UploadModal from './UploadModal';

export default function ProjectsSection() {
  const [expandedProjects, setExpandedProjects] = useState<number[]>([1]);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedMilestone, setSelectedMilestone] = useState<any>(null);

  const projects = [
    {
      id: 1,
      title: 'Infrastructure Development – Zone A',
      status: 'active',
      description: 'Development of road infrastructure and drainage systems in residential zone A',
      budget: '₹45,00,000',
      dprDeadline: '2024-12-15',
      overallProgress: 65,
      milestones: [
        {
          id: 1,
          name: 'Site Survey & Assessment',
          status: 'completed',
          deadline: '2024-10-20',
          milestoneName: 'Site Survey & Assessment', // Under What Milestone
          expectedOutput: 'Detailed site survey report with measurements and photographs',
          uploads: [
            { type: 'image', name: 'site_photo_1.jpg' },
            { type: 'image', name: 'site_photo_2.jpg' },
            { type: 'file', name: 'survey_report.pdf' },
          ],
        },
        {
          id: 2,
          name: 'DPR Draft Preparation',
          status: 'in-progress',
          deadline: '2024-11-30',
          milestoneName: 'DPR Draft Preparation', // Under What Milestone
          expectedOutput: 'Complete DPR with cost estimates and technical specifications',
          uploads: [
            { type: 'file', name: 'draft_dpr_v1.docx' },
          ],
        },
        {
          id: 3,
          name: 'Final DPR Submission',
          status: 'pending',
          deadline: '2024-12-15',
          milestoneName: 'Final DPR Submission', // Under What Milestone
          expectedOutput: 'Final approved DPR with all necessary approvals',
          uploads: [],
        },
      ],
      managerEvaluation: {
        qualityScore: 8.5,
        technicalCompliance: 9.0,
        remarks: 'Excellent work on site survey. DPR draft needs minor revisions in cost estimates.',
      },
    },
    {
      id: 2,
      title: 'Rural Road Construction – Block 12',
      status: 'active',
      description: 'Construction of 5km rural road connecting villages in Block 12',
      budget: '₹78,50,000',
      dprDeadline: '2024-12-20',
      overallProgress: 40,
      milestones: [
        {
          id: 1,
          name: 'Preliminary Survey',
          status: 'completed',
          deadline: '2024-10-15',
          milestoneName: 'Preliminary Survey', // Under What Milestone
          expectedOutput: 'Route survey and feasibility report',
          uploads: [
            { type: 'image', name: 'route_survey_1.jpg' },
            { type: 'file', name: 'feasibility_report.pdf' },
          ],
        },
        {
          id: 2,
          name: 'Soil Testing & Analysis',
          status: 'in-progress',
          deadline: '2024-11-25',
          milestoneName: 'Soil Testing & Analysis', // Under What Milestone
          expectedOutput: 'Soil test reports and foundation recommendations',
          uploads: [],
        },
      ],
      managerEvaluation: {
        qualityScore: 8.0,
        technicalCompliance: 8.5,
        remarks: 'Good progress. Ensure soil testing is completed on schedule.',
      },
    },
  ];

  const toggleProject = (projectId: number) => {
    if (expandedProjects.includes(projectId)) {
      setExpandedProjects(expandedProjects.filter(id => id !== projectId));
    } else {
      setExpandedProjects([...expandedProjects, projectId]);
    }
  };

  const handleUploadClick = (milestone: any) => {
    setSelectedMilestone(milestone);
    setUploadModalOpen(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'pending':
        return 'bg-gray-100 text-gray-700 border-gray-300';
      case 'active':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'delayed':
        return 'bg-red-100 text-red-700 border-red-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="size-4" />;
      case 'in-progress':
        return <Clock className="size-4" />;
      case 'pending':
        return <AlertCircle className="size-4" />;
      default:
        return null;
    }
  };

  const getDaysUntilDeadline = (deadline: string) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-[#1C1C28] text-xl">My Projects</h2>
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
          {projects.length} Active Projects
        </Badge>
      </div>

      {projects.map((project) => {
        const isExpanded = expandedProjects.includes(project.id);
        const daysLeft = getDaysUntilDeadline(project.dprDeadline);

        return (
          <div key={project.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
            {/* Project Header */}
            <div className="p-6 border-b">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-[#1C1C28] text-lg">{project.title}</h3>
                    <Badge className={getStatusColor(project.status)} variant="outline">
                      {project.status}
                    </Badge>
                  </div>
                  <p className="text-[#6B6B6B] mb-3">{project.description}</p>
                  <div className="flex items-center gap-6 text-sm">
                    <div>
                      <span className="text-[#6B6B6B]">Budget: </span>
                      <span className="text-[#1C1C28]">{project.budget}</span>
                    </div>
                    <div>
                      <span className="text-[#6B6B6B]">DPR Deadline: </span>
                      <span
                        className={`${daysLeft < 7 ? 'text-red-600' : daysLeft < 14 ? 'text-orange-600' : 'text-green-600'
                          }`}
                      >
                        {project.dprDeadline} ({daysLeft} days left)
                      </span>
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => toggleProject(project.id)}
                >
                  {isExpanded ? <ChevronUp className="size-5" /> : <ChevronDown className="size-5" />}
                </Button>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-[#6B6B6B]">Overall Progress</span>
                  <span className="text-sm text-[#1C1C28]">{project.overallProgress}%</span>
                </div>
                <div className="bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all"
                    style={{ width: `${project.overallProgress}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Expanded Content - Milestones */}
            {isExpanded && (
              <div className="p-6 space-y-4">
                <h4 className="text-[#1C1C28]">My Tasks</h4>
                {project.milestones.map((milestone) => (
                  <div
                    key={milestone.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {getStatusIcon(milestone.status)}
                          <span className="text-[#1C1C28]">{milestone.name}</span>
                          <Badge className={getStatusColor(milestone.status)} variant="outline">
                            {milestone.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-[#6B6B6B] mb-2">
                          Deadline: {milestone.deadline}
                        </div>
                        <div className="text-sm text-[#6B6B6B] mb-2">
                          Under What Milestone: {milestone.milestoneName || milestone.name}
                        </div>
                        <div className="text-sm text-[#6B6B6B]">
                          Expected Output: {milestone.expectedOutput}
                        </div>
                      </div>
                    </div>

                    {/* Uploaded Files */}
                    {milestone.uploads.length > 0 && (
                      <div className="mb-3 p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-[#6B6B6B] mb-2">Uploaded Files:</div>
                        <div className="flex flex-wrap gap-2">
                          {milestone.uploads.map((upload, idx) => (
                            <div
                              key={idx}
                              className="flex items-center gap-2 bg-white px-3 py-2 rounded border"
                            >
                              {upload.type === 'image' ? (
                                <ImageIcon className="size-4 text-blue-600" />
                              ) : (
                                <FileText className="size-4 text-green-600" />
                              )}
                              <span className="text-sm text-[#1C1C28]">{upload.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      {milestone.status === 'in-progress' && (
                        <>
                          <Button
                            onClick={() => handleUploadClick(milestone)}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Upload className="size-4 mr-2" />
                            Upload Files
                          </Button>
                          <Button variant="outline">
                            <CheckCircle className="size-4 mr-2" />
                            Complete Milestone
                          </Button>
                        </>
                      )}
                      {milestone.status === 'pending' && (
                        <Button
                          onClick={() => handleUploadClick(milestone)}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          Start & Upload Proof
                        </Button>
                      )}
                    </div>
                  </div>
                ))}

                {/* Manager Evaluation */}
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="text-[#1C1C28] mb-3">Manager Evaluation</h4>
                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div>
                      <div className="text-sm text-[#6B6B6B] mb-1">Quality Score</div>
                      <div className="text-2xl text-[#1C1C28]">
                        {project.managerEvaluation.qualityScore}/10
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-[#6B6B6B] mb-1">Technical Compliance</div>
                      <div className="text-2xl text-[#1C1C28]">
                        {project.managerEvaluation.technicalCompliance}/10
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-[#6B6B6B] mb-1">Manager Remarks</div>
                    <div className="text-[#1C1C28]">{project.managerEvaluation.remarks}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* Upload Modal */}
      {uploadModalOpen && selectedMilestone && (
        <UploadModal
          milestone={selectedMilestone}
          onClose={() => setUploadModalOpen(false)}
        />
      )}
    </div>
  );
}
