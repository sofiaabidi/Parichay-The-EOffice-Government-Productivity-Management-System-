import { useState } from "react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Star } from "lucide-react";
import { toast } from "sonner";

interface PeerFeedbackDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFeedbackAdded?: () => void;
}

export function PeerFeedbackDialog({ open, onOpenChange, onFeedbackAdded }: PeerFeedbackDialogProps) {
  const [loading, setLoading] = useState(false);
  const [feedbackData, setFeedbackData] = useState({
    toUserId: "",
    regarding: "",
    rating: 0,
    comment: "",
  });

  // Dummy peers data for Field Employee
  const peers = [
    { id: 1, name: "Rajesh Kumar", designation: "Field Engineer" },
    { id: 2, name: "Priya Sharma", designation: "Surveyor" },
    { id: 3, name: "Amit Patel", designation: "Site Supervisor" },
    { id: 4, name: "Sneha Reddy", designation: "Project Coordinator" },
    { id: 5, name: "Vikram Singh", designation: "Field Engineer" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!feedbackData.toUserId || !feedbackData.rating) {
      toast.error("Please select a peer and provide a rating");
      return;
    }

    try {
      setLoading(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const selectedPeer = peers.find(p => p.id === Number(feedbackData.toUserId));
      toast.success(`Feedback added successfully for ${selectedPeer?.name || 'peer'}`);
      
      setFeedbackData({
        toUserId: "",
        regarding: "",
        rating: 0,
        comment: "",
      });
      onOpenChange(false);
      
      if (onFeedbackAdded) {
        onFeedbackAdded();
      }
    } catch (error: any) {
      toast.error("Failed to add feedback");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Peer-to-Peer Feedback</DialogTitle>
          <DialogDescription>
            Provide feedback for your teammates.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="peer">Select Teammate *</Label>
            <Select
              value={feedbackData.toUserId}
              onValueChange={(value) =>
                setFeedbackData({ ...feedbackData, toUserId: value })
              }
              required
            >
              <SelectTrigger id="peer">
                <SelectValue placeholder="Choose a teammate" />
              </SelectTrigger>
              <SelectContent>
                {peers.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No teammates available
                  </SelectItem>
                ) : (
                  peers.map((peer) => (
                    <SelectItem key={peer.id} value={peer.id.toString()}>
                      {peer.name} - {peer.designation || 'Employee'}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="regarding">Regarding (Re:)</Label>
            <Input
              id="regarding"
              placeholder="e.g., Collaboration, Problem-solving"
              value={feedbackData.regarding}
              onChange={(e) =>
                setFeedbackData({ ...feedbackData, regarding: e.target.value })
              }
            />
          </div>

          <div className="space-y-2">
            <Label>Rating *</Label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setFeedbackData({ ...feedbackData, rating: star })}
                  className="focus:outline-none"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= feedbackData.rating
                        ? "fill-yellow-400 text-yellow-400"
                        : "fill-gray-200 text-gray-200"
                    }`}
                  />
                </button>
              ))}
              {feedbackData.rating > 0 && (
                <span className="ml-2 text-sm text-gray-600">
                  {feedbackData.rating} / 5
                </span>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="comment">Description</Label>
            <Textarea
              id="comment"
              placeholder="Add your feedback comments..."
              rows={4}
              value={feedbackData.comment}
              onChange={(e) =>
                setFeedbackData({ ...feedbackData, comment: e.target.value })
              }
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={loading}>
              {loading ? "Submitting..." : "Submit Feedback"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

