import { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";

import TopNavBar from './components/TopNavBar';
import KPISection from './components/KPISection';
import ProjectsSection from './components/ProjectsSection';
import SurveysSection from './components/SurveysSection';
import TrainingProgramsSection from './components/TrainingProgramsSection';
import FeedbackSection from './components/FeedbackSection';
import { MapSection } from './components/MapSection';

export default function FieldEmployeeApp() {
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [checkInTime, setCheckInTime] = useState<Date | null>(null);
  const [totalHours, setTotalHours] = useState<number | null>(null);

  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    localStorage.clear();
    navigate("/");
  };

  const handleCheckIn = () => {
    setIsCheckedIn(true);
    setCheckInTime(new Date());
    setTotalHours(null);
  };

  const handleCheckOut = () => {
    if (checkInTime) {
      const now = new Date();
      const diff = now.getTime() - checkInTime.getTime();
      const hours = diff / (1000 * 60 * 60);
      setTotalHours(parseFloat(hours.toFixed(2)));
    }
    setIsCheckedIn(false);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FB]">

      <TopNavBar
        isCheckedIn={isCheckedIn}
        onCheckIn={handleCheckIn}
        onCheckOut={handleCheckOut}
        totalHours={totalHours}
      />

      <main className="max-w-[1440px] mx-auto px-6 py-8 space-y-8">
        <KPISection />
        <ProjectsSection />
        <SurveysSection />
        <MapSection />
        <TrainingProgramsSection />
        <FeedbackSection />
      </main>
    </div>
  );
}
