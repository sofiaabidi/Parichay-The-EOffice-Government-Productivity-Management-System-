-- Seed data for Field Employee KPI calculations
-- This creates dummy data for testing KPI calculations

-- DPR Reviews for Field Employees (Assam Region)
-- Employee 10 (Arjun Sharma) - Project 4
INSERT INTO dpr_reviews (
  project_id, reviewed_by, reviewed_for,
  actual_submission_date, deadline,
  authenticity_stars, data_correctness_stars,
  technical_correctness_stars, completeness_stars,
  tools_and_resources_stars, remarks
)
VALUES
  (4, 9, 10, CURRENT_DATE - INTERVAL '2 days', CURRENT_DATE - INTERVAL '5 days', 4, 5, 4, 5, 4, 'Good DPR submission'),
  (4, 9, 10, CURRENT_DATE - INTERVAL '30 days', CURRENT_DATE - INTERVAL '33 days', 5, 4, 5, 4, 5, 'Excellent work'),
  (4, 9, 10, CURRENT_DATE - INTERVAL '60 days', CURRENT_DATE - INTERVAL '62 days', 4, 4, 4, 4, 4, 'Satisfactory submission')
ON CONFLICT (project_id, reviewed_for, reviewed_by) DO UPDATE SET
  actual_submission_date = EXCLUDED.actual_submission_date,
  deadline = EXCLUDED.deadline,
  authenticity_stars = EXCLUDED.authenticity_stars,
  data_correctness_stars = EXCLUDED.data_correctness_stars,
  technical_correctness_stars = EXCLUDED.technical_correctness_stars,
  completeness_stars = EXCLUDED.completeness_stars,
  tools_and_resources_stars = EXCLUDED.tools_and_resources_stars,
  updated_at = NOW();

-- Employee 11 (Priya Das) - Project 5
INSERT INTO dpr_reviews (
  project_id, reviewed_by, reviewed_for,
  actual_submission_date, deadline,
  authenticity_stars, data_correctness_stars,
  technical_correctness_stars, completeness_stars,
  tools_and_resources_stars, remarks
)
VALUES
  (5, 9, 11, CURRENT_DATE - INTERVAL '1 day', CURRENT_DATE - INTERVAL '3 days', 5, 5, 4, 5, 5, 'Outstanding submission'),
  (5, 9, 11, CURRENT_DATE - INTERVAL '28 days', CURRENT_DATE - INTERVAL '30 days', 4, 5, 5, 4, 5, 'Very good work')
ON CONFLICT (project_id, reviewed_for, reviewed_by) DO UPDATE SET
  actual_submission_date = EXCLUDED.actual_submission_date,
  deadline = EXCLUDED.deadline,
  authenticity_stars = EXCLUDED.authenticity_stars,
  data_correctness_stars = EXCLUDED.data_correctness_stars,
  technical_correctness_stars = EXCLUDED.technical_correctness_stars,
  completeness_stars = EXCLUDED.completeness_stars,
  tools_and_resources_stars = EXCLUDED.tools_and_resources_stars,
  updated_at = NOW();

-- Update tasks with planned_duration and planned_completion_date for task timeliness calculation
-- Employee 10 tasks
UPDATE tasks 
SET 
  planned_duration = 5, -- days
  planned_completion_date = due_date,
  cost = '₹2,50,000'
WHERE id = 10 AND assigned_to = 10;

UPDATE tasks 
SET 
  planned_duration = 7, -- days
  planned_completion_date = due_date,
  cost = '₹4,00,000'
WHERE id = 14 AND assigned_to = 10;

-- Employee 11 tasks
UPDATE tasks 
SET 
  planned_duration = 6, -- days
  planned_completion_date = due_date,
  cost = '₹2,50,000'
WHERE id = 11 AND assigned_to = 11;

UPDATE tasks 
SET 
  planned_duration = 8, -- days
  planned_completion_date = due_date,
  cost = '₹4,00,000'
WHERE id = 15 AND assigned_to = 11;

-- Update completed tasks with completed_at dates
UPDATE tasks 
SET completed_at = due_date + INTERVAL '1 day'
WHERE id IN (10, 11, 14, 15) AND status = 'completed';

-- Update surveys to ensure they have total_area and expected_time
UPDATE surveys
SET 
  total_area = COALESCE(total_area, '10000'),
  expected_time = COALESCE(expected_time, '50')
WHERE created_by = 9 AND (total_area IS NULL OR expected_time IS NULL);

-- Update survey submissions with proper area_covered and time_taken
-- Employee 10 survey submissions
UPDATE survey_submissions
SET 
  area_covered = '8500',
  time_taken = '45',
  approval_status = 'approved',
  submitted_at = NOW() - INTERVAL '10 days'
WHERE submitted_by = 10 AND survey_id IN (SELECT id FROM surveys WHERE created_by = 9 LIMIT 1);

-- Employee 11 survey submissions
UPDATE survey_submissions
SET 
  area_covered = '9200',
  time_taken = '48',
  approval_status = 'approved',
  submitted_at = NOW() - INTERVAL '8 days'
WHERE submitted_by = 11 AND survey_id IN (SELECT id FROM surveys WHERE created_by = 9 LIMIT 1);

-- Add supervisor ratings for surveys
-- First, create survey field visits if they don't exist
INSERT INTO survey_field_visits (survey_id, visited_by, visit_date, notes)
SELECT s.id, 9, CURRENT_DATE - INTERVAL '5 days', 'Field visit for survey evaluation'
FROM surveys s
WHERE s.created_by = 9
LIMIT 2
ON CONFLICT DO NOTHING;

-- Add supervisor ratings for employees
INSERT INTO supervisor_ratings (survey_field_visit_id, employee_id, rating, notes)
SELECT sfv.id, 10, 8.5, 'Good survey work'
FROM survey_field_visits sfv
JOIN surveys s ON s.id = sfv.survey_id
WHERE s.created_by = 9
LIMIT 1
ON CONFLICT DO NOTHING;

INSERT INTO supervisor_ratings (survey_field_visit_id, employee_id, rating, notes)
SELECT sfv.id, 11, 9.0, 'Excellent survey accuracy'
FROM survey_field_visits sfv
JOIN surveys s ON s.id = sfv.survey_id
WHERE s.created_by = 9
LIMIT 1
ON CONFLICT DO NOTHING;

-- Ensure project evaluations have technical_compliance for employees
-- Link project evaluations to employees via project_members
INSERT INTO project_members (project_id, user_id)
SELECT DISTINCT pe.project_id, pm.user_id
FROM project_evaluations pe
JOIN projects p ON p.id = pe.project_id
JOIN project_members pm ON pm.project_id = p.id
WHERE pm.user_id IN (10, 11, 12, 13)
ON CONFLICT DO NOTHING;

-- Add initial dummy KPI snapshots for field employees (current month)
-- This provides starting KPI values that will be updated when recalculation triggers fire
INSERT INTO field_employee_kpi_snapshots (
  user_id, period_start, period_end,
  dpr_kpi, technical_compliance_kpi, survey_kpi,
  expenditure_kpi, task_timeliness_kpi, final_kpi
)
VALUES
  -- Employee 10 (Arjun Sharma) - Assam Region
  (10, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 75.0, 80.0, 70.0, 85.0, 78.0, 77.6),
  -- Employee 11 (Priya Das) - Assam Region
  (11, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 82.0, 85.0, 88.0, 80.0, 85.0, 84.0),
  -- Employee 12 (Amit Kumar) - Assam Region
  (12, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 70.0, 75.0, 65.0, 75.0, 72.0, 71.4),
  -- Employee 13 (Sneha Reddy) - Assam Region
  (13, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 68.0, 72.0, 68.0, 70.0, 70.0, 69.6),
  -- Employee 15 (Neha Verma) - Arunachal Pradesh Region
  (15, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 80.0, 82.0, 75.0, 88.0, 80.0, 81.0),
  -- Employee 16 (Rohit Desai) - Arunachal Pradesh Region
  (16, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 75.0, 78.0, 72.0, 80.0, 75.0, 76.0),
  -- Employee 17 (Kavita Nair) - Arunachal Pradesh Region
  (17, date_trunc('month', CURRENT_DATE)::date, (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 78.0, 80.0, 78.0, 82.0, 78.0, 79.2)
ON CONFLICT (user_id, period_start, period_end) DO UPDATE SET
  dpr_kpi = EXCLUDED.dpr_kpi,
  technical_compliance_kpi = EXCLUDED.technical_compliance_kpi,
  survey_kpi = EXCLUDED.survey_kpi,
  expenditure_kpi = EXCLUDED.expenditure_kpi,
  task_timeliness_kpi = EXCLUDED.task_timeliness_kpi,
  final_kpi = EXCLUDED.final_kpi,
  updated_at = NOW();

